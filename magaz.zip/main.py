#Mag-AZ team, Azores, Portugal

"""This is the beggining of our code. Our goal is to get all the data needed in order
to build and test an algorithm that calculates the location of the
magnetic poles of a stellar body (if they have one; in this case, the Earth)."""


#imported libraries

from sense_hat import SenseHat 
from ephem import readtle, degree
from time import sleep
from pathlib import Path
from datetime import datetime, timedelta
from logzero import logger, logfile
from sys import exit as exit_program
import csv
import os


#directory of files

"""data01.csv -> file with sensor readings
Mag-AZ.log -> file with logging data
starttime.txt -> reference time in case a reboot occurs"""

dir_path = Path(__file__).parent.resolve()
data_file = dir_path/'data01.csv'
logfile(dir_path/'Mag-AZ.log')
time_file = dir_path/'starttime.txt'


#8x8 RGB LED matrix (compass)

"""The following sets of pixels are part of the compass we have
built that always follows the direction of the magnetic field"""

O=(128,0,0) #red colour
x=(0,0,0) #no colour

arrow_straight=[
x,x,x,x,x,x,x,x,
x,x,x,x,x,x,x,x,
x,x,x,x,O,x,x,x,
x,x,x,x,O,O,x,x,
O,O,O,O,O,O,O,x,
x,x,x,x,O,O,x,x,
x,x,x,x,O,x,x,x,
x,x,x,x,x,x,x,x
]

arrow_weird_1=[
x,x,x,x,x,x,x,x,
x,x,x,x,x,x,x,x,
O,O,x,x,O,x,x,x,
x,x,O,O,O,O,x,x,
x,x,x,x,O,O,O,x,
x,x,x,O,O,O,O,O,
x,x,x,x,x,x,x,x,
x,x,x,x,x,x,x,x
]

arrow_diagonal=[
x,x,x,x,x,x,x,x,
x,O,x,x,x,x,x,x,
x,x,O,x,x,x,x,x,
x,x,x,O,x,x,O,x,
x,x,x,x,O,O,O,x,
x,x,x,x,O,O,O,x,
x,x,x,O,O,O,O,x,
x,x,x,x,x,x,x,x
]

arrow_weird_2=[
x,x,O,x,x,x,x,x,
x,x,O,x,x,x,x,x,
x,x,x,O,x,x,x,x,
x,x,x,O,x,O,x,x,
x,x,O,O,O,O,x,x,
x,x,x,O,O,O,x,x,
x,x,x,x,O,O,x,x,
x,x,x,x,x,O,x,x
]

arrow_dictionary={
0:arrow_straight,
1:arrow_weird_1,
2:arrow_diagonal,
3:arrow_weird_2
}

"""This set of pixels is to visualy certify the astronauts 
that our code has fineshed running"""

end_pixels=[
x,x,x,x,x,x,x,x,
x,x,x,x,x,O,O,x,
x,x,x,x,O,O,O,x,
O,O,x,O,O,O,x,x,
O,O,O,O,O,x,x,x,
x,O,O,O,x,x,x,x,
x,x,O,x,x,x,x,x,
x,x,x,x,x,x,x,x
]

"""And now some functions"""

def arrow_compass():
	"""Displays a compass on the LED display"""
	angle = 360-sense.get_compass()
	id = round(angle/22.5)%16
	sense.set_rotation((id//4)*90)
	sense.set_pixels(arrow_dictionary[id%4])

def loading_animation():
	"""Makes the arrow spin a few times to show the program is working"""
	rotation=0
	sense.set_rotation(0)
	for a in range(12):
		sense.set_pixels(arrow_straight)
		sleep(0.06)					
		sense.set_pixels(arrow_weird_1)
		sleep(0.06)
		sense.set_pixels(arrow_diagonal)
		sleep(0.06)
		sense.set_pixels(arrow_weird_2)
		sleep(0.06)
		rotation = (rotation+90)%360
		sense.set_rotation(rotation)


#Sensor data

def mag_data():
	"""Returns the magnetometer data in microteslas"""
	mag = sense.get_compass_raw()
	return [round(mag['x'],4),round(mag['y'],4),round(mag['z'],4)]

def gyro_data():
	"""Returns the gyroscope data in degrees/second (dps)"""
	gyro = sense.get_gyroscope_raw()
	return [round(gyro['x'],8),round(gyro['y'],8),round(gyro['z'],8)]

def orientation_data():
	"""Returns the orientation data in degrees"""
	ori = sense.get_orientation()
	return [round(ori['pitch'],3),round(ori['roll'],3),round(ori['yaw'],3)]


#ISS coordinates

def iss_ini():
	"""Creates the "iss" object to later determine the ISS's location"""
	global iss
	name='ISS (ZARYA)'
	line1 = "1 25544U 98067A   21050.35666428  .00001943  00000-0  43448-4 0  9992"
	line2 = "2 25544  51.6441 205.5251 0003032  33.1814  49.2099 15.48980511270331"
	iss = readtle(name, line1, line2)

def iss_pos():
	"""Determines the position of the ISS on a point in space"""
	iss.compute()
	return [round(iss.sublat/degree,4),round(iss.sublong/degree,4),round(iss.elevation,0)]


#First_boot n Reboot

def first_boot():
	"""If no 'starttime.txt' file was previously generated, this means the program is running for the first time.
	Therefore, a 'starttime.txt' file will be created, to use in case of reboot"""
	global rebooted, start_time
	start_time = datetime.now()
	f = open(time_file,'w')
	f.write(str(start_time))
	f.close()
	rebooted = False
	logger.info('Starting program...')
	sense.show_message('Hi! The Mag-AZ experience is about to begin.',text_colour=O,back_colour=x,scroll_speed=0.05)
	sense.show_message('This arrow is a compass.',text_colour=O,back_colour=x,scroll_speed=0.05)

def reboot():
	"""If the 'starttime.txt' file already exists, the experiment was started previously.
	The data logging proceeds from where it was in order to	avoid exceeding the 3 hours limit.
	It relies on the time provided by the OS."""
	global rebooted, start_time
	f = open(time_file,'r')
	start_time = datetime.fromisoformat(f.read())
	f.close()
	rebooted = True
	logger.info('Restarting program...')


#Run section

sense = SenseHat()
iss_ini()

loading_animation()

"""Controls what is going to be displayed on the LED display if a reboot occurs"""
try:
	reboot()
	time_elapsed = datetime.now() - start_time
	if time_elapsed < timedelta(minutes=175):
		sense.show_message('Oops! I crashed.',text_colour=O,back_colour=x,scroll_speed=0.05)
	else:
		sense.show_message('Data already collected.',text_colour=O,back_colour=x,scroll_speed=0.05)

except:
	first_boot()

time_elapsed = datetime.now() - start_time

if time_elapsed > timedelta(minutes=175):
	"""Once the 3 hour experiment has finished, a warning will be given if the code is ran again.
	This helps us avoid losing collected data and facilitate the astronauts rerun the program if it is needed.
	We are aware that experiments musn't rely on astronaut interaction.
	The program will run correctly by itself.
	This is simply a security measure, and an add-on."""
	logger.warning('The 3 hour experiment has finished.')
	logger.warning('The program will rerun in 40 seconds.')
	logger.warning('If you run the program again, all previously collected data will be deleted.')
	logger.warning('If you would like to, you can also delete the starttime.txt file and rerun the program.')
	logger.warning('Closing the program now won\'t damage the files generated before.')
	logger.warning('Are you sure you want to RERUN the program?')
	sleep(30)
	logger.warning('10 seconds left. This is your final warning.')
	sleep(10)
	os.remove(time_file)
	first_boot()

if rebooted == False:
	"""Generates the 'data01.csv' file if its the first time the code is running"""
	with open(data_file,'w',encoding='utf-8') as f:
		csv_writer = csv.writer(f)
		header = "ID","Time Elapsed","Magnetometer/\u03BCT (x)","(y)","(z)","Gyroscope/dps (x)","(y)","(z)","ISS (Latitude/degrees)","(Longitude/degrees)","(Altitude/m)","Orientation/degrees (pitch)","(roll)","(yaw)" #\u03BC -> micro
		csv_writer.writerow(header)
	row_ID = 1
else:
	"""Proceeds to continue logging data with the correct row's IDs if a reboot happens"""
	with open(data_file,'r',encoding='utf-8') as f:
		row_ID = sum(1 for row in f)

time_elapsed = datetime.now() - start_time

while time_elapsed < timedelta(minutes=175):
	try:
		"""Fills both the data01.csv and Mag-AZ.log files with the corresponding data"""
		with open(data_file,'a',encoding='utf-8') as f:
			csv_writer = csv.writer(f)
			time_elapsed = datetime.now() - start_time
			csv_writer.writerow([row_ID,time_elapsed] + mag_data() + gyro_data() + iss_pos() + orientation_data())
		logger.info(f'Row {row_ID} was registered successfully.')
		row_ID += 1
	except:
		logger.error('Sensor error.')
	
	try:
		"""Displays a compass on the LED display, refreshing every 2 seconds"""
		arrow_compass()
		sleep(1.5)
		sense.clear()
		sleep(0.5)
	except:
		logger.error('LED display error.')
		sleep(2)

sense.show_message('This is the end of our amAZing experience. Goodbye!',text_colour=O,back_colour=x,scroll_speed=0.05)
sense.set_pixels(end_pixels)
logger.info('The program has concluded running.')

"""In order for our code to work the way it is intended to, the 'starttime.txt' file should not exist
in the directory of the main.py file at the beginning of the code execution. If, by any chance, the
starttime.txt file happens to already exist before it, the program will either give a warning (lines 220-225)
or run for less than 3 hours. For this reason, if the astronauts want to rerun the program, we have built an
automatic restart option. Once again, we are aware that experiments musn't rely on astronaut interaction.
This feature doesn't need human input to be used, but there is a safeguard measure in case it wasn't intended
for the code to rerun. It helps us prevent data loss. We also tested the memory the files might ocupy and all
have less than 20MB of data."""

#end of code